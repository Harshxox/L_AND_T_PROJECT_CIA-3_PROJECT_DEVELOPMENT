const jwt = require('jsonwebtoken');
const User = require('../models/User');

const protect = async (req, res, next) => {
  let token;

  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
    token = req.headers.authorization.split(' ')[1];
  }

  if (!token) {
    return res.status(401).json({
      success: false,
      message: 'Not authorized to access this route. Missing token.',
      errorCode: 'UNAUTHORIZED'
    });
  }

  try {
    // Verify token
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    // Get user from the token, exclude passwordHash
    req.user = await User.findById(decoded.id);

    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: 'The user belonging to this token does no longer exist.',
        errorCode: 'UNAUTHORIZED'
      });
    }

    next();
  } catch (error) {
    let message = 'Not authorized to access this route. Invalid token.';
    if (error.name === 'TokenExpiredError') {
      message = 'Token has expired. Please login again.';
    }
    
    return res.status(401).json({
      success: false,
      message: message,
      errorCode: 'UNAUTHORIZED'
    });
  }
};

module.exports = { protect };
